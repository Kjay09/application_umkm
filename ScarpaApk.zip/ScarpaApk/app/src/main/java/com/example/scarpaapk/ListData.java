package com.example.scarpaapk;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ListData extends AppCompatActivity {
    ListView listView;
    Button btnBack,btnDone;
    DataBaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listdata);

        listView = findViewById(R.id.lv_data);
        btnBack = findViewById(R.id.btn_back);
        btnDone = findViewById(R.id.btn_done);
        dbHelper = new DataBaseHelper(this);

        List<String> dataList = getDataFromDatabase();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        listView.setAdapter(adapter);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(ListData.this, Purchasing.class);
                startActivity(back);
            }
        });

        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ListData.this, "Transaksi Berhasil", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private List<String> getDataFromDatabase() {
        List<String> dataList = new ArrayList<>();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                DataBaseContract.DataEntry.COLUMN_NAME,
                DataBaseContract.DataEntry.COLUMN_ALAMAT,
                DataBaseContract.DataEntry.COLUMN_PHONE,
                DataBaseContract.DataEntry.COLUMN_ITEM,
                DataBaseContract.DataEntry.COLUMN_JUMLAH,
                DataBaseContract.DataEntry.COLUMN_TOTAL
        };

        String sortOrder = DataBaseContract.DataEntry.COLUMN_NAME + " ASC";

        Cursor cursor = db.query(
                DataBaseContract.DataEntry.TABLE_NAME, projection, null,
                null, null, null, sortOrder
        );

        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_NAME));
            String alamat = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_ALAMAT));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_PHONE));
            String item = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_ITEM));
            String jumlah = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_JUMLAH));
            String total = cursor.getString(cursor.getColumnIndexOrThrow(DataBaseContract.DataEntry.COLUMN_TOTAL));

            dataList.add("Name: " + name + "\n" + "Alamat: " + alamat + "\n" + "Phone: " + phone + "\n" +
                    "Item: " + item + "\n" + "Jumlah: " + jumlah + "\n" + "Total: " + total);
        }
        cursor.close();
        return dataList;
    }
}
