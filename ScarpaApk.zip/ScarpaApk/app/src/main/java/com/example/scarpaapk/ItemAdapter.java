package com.example.scarpaapk;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ItemAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Item> infolist;
    public ItemAdapter(Context context, ArrayList<Item>infolist){
        this.context = context;
        this.infolist = infolist;
    }
    @Override
    public int getCount(){return infolist.size();}
    @Override
    public Object getItem(int position){return infolist.get(position);}
    @Override
    public long getItemId(int position){return position;}
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;
        ViewHolder viewHolder;
        if(view==null){
            view = LayoutInflater.from(context).inflate(R.layout.destination_item,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.textView = view.findViewById(R.id.tv_details);
            view.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) view.getTag();
        }
        Item item = (Item) getItem(position);
        viewHolder.textView.setText(item.getNamaproduk());
        return view;
    }
    static class ViewHolder{
        TextView textView;
    }
}
