package com.example.scarpaapk;

import android.provider.BaseColumns;

public final class DataBaseContract {
    private DataBaseContract() {}

    public static class DataEntry implements BaseColumns {
        public static final String TABLE_NAME = "pendataan";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_ALAMAT = "alamat";
        public static final String COLUMN_PHONE = "phone";
        public static final String COLUMN_ITEM = "item";
        public static final String COLUMN_JUMLAH = "jumlah";
        public static final String COLUMN_TOTAL = "total";
    }
}

