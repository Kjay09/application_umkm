package com.example.scarpaapk;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Purchasing extends AppCompatActivity {
    EditText etName, etAlamat, etItem, etPhone,etJumlah, etTotal;
    Button btnInsert,btnDelete,btnSelect,btnUpdate,btnBack;
    DataBaseHelper dbHelper;
    TextView tvTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchasing);

        dbHelper = new DataBaseHelper(this);
        etName = findViewById(R.id.edt_name);
        etAlamat = findViewById(R.id.edt_email);
        etPhone = findViewById(R.id.edt_telp);
        etItem = findViewById(R.id.edt_item);
        etJumlah = findViewById(R.id.edt_jumlah);
        etTotal = findViewById(R.id.edt_total);
        btnInsert = findViewById(R.id.btn_Insert);
        btnSelect = findViewById(R.id.btn_Select);
        btnUpdate = findViewById(R.id.btn_Update);
        btnDelete = findViewById(R.id.btn_Delete);
        btnBack = findViewById(R.id.btn_Goback);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String email = etAlamat.getText().toString();
                String item = etItem.getText().toString();
                String phone = etPhone.getText().toString();
                String jumlah = etJumlah.getText().toString();
                String total = etTotal.getText().toString();

                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || item.isEmpty() || jumlah.isEmpty() || total.isEmpty()) {
                    Toast.makeText(Purchasing.this, "Data belum lengkap", Toast.LENGTH_SHORT).show();
                } else {
                    long result = insertData(name, email, phone, item, jumlah, total);
                    if (result != -1) {
                        Toast.makeText(Purchasing.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Purchasing.this, ListData.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(Purchasing.this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Purchasing.this, ListData.class);
                startActivity(intent);
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String email = etAlamat.getText().toString();
                String item = etItem.getText().toString();
                String phone = etPhone.getText().toString();
                String jumlah = etJumlah.getText().toString();
                String total = etTotal.getText().toString();

                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(DataBaseContract.DataEntry.COLUMN_NAME, name);
                values.put(DataBaseContract.DataEntry.COLUMN_ALAMAT, email);
                values.put(DataBaseContract.DataEntry.COLUMN_PHONE, phone);
                values.put(DataBaseContract.DataEntry.COLUMN_ITEM, item);
                values.put(DataBaseContract.DataEntry.COLUMN_JUMLAH, jumlah);
                values.put(DataBaseContract.DataEntry.COLUMN_TOTAL, total);

                String selection = DataBaseContract.DataEntry.COLUMN_NAME + " LIKE ?";
                String[] selectionArgs = { name };

                // Melakukan operasi update pada database
                int count = db.update(DataBaseContract.DataEntry.TABLE_NAME, values, selection, selectionArgs);

                // Menampilkan pesan berdasarkan hasil update
                if (count > 0) {
                    Toast.makeText(Purchasing.this, "Data berhasil diupdate", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Purchasing.this, "Gagal mengupdate data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAllData();
                Toast.makeText(Purchasing.this, "Data berhasil dihapus", Toast.LENGTH_SHORT).show();
            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Purchasing.this,Homepage.class);
                startActivity(intent);
            }
        });
    }

    private long insertData(String name, String email, String phone, String item, String jumlah, String total) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DataBaseContract.DataEntry.COLUMN_NAME, name);
        values.put(DataBaseContract.DataEntry.COLUMN_ALAMAT, email);
        values.put(DataBaseContract.DataEntry.COLUMN_PHONE, phone);
        values.put(DataBaseContract.DataEntry.COLUMN_ITEM, item);
        values.put(DataBaseContract.DataEntry.COLUMN_JUMLAH, jumlah);
        values.put(DataBaseContract.DataEntry.COLUMN_TOTAL, total);
        return db.insert(DataBaseContract.DataEntry.TABLE_NAME, null, values);
    }

    private void deleteAllData() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DataBaseContract.DataEntry.TABLE_NAME, null, null);
    }
}

