package com.example.scarpaapk;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "data_user.db";
    private static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + DataBaseContract.DataEntry.TABLE_NAME + " (" +
                    DataBaseContract.DataEntry._ID + " INTEGER PRIMARY KEY," +
                    DataBaseContract.DataEntry.COLUMN_NAME + " TEXT," +
                    DataBaseContract.DataEntry.COLUMN_ALAMAT + " TEXT," +
                    DataBaseContract.DataEntry.COLUMN_PHONE + " TEXT," +
                    DataBaseContract.DataEntry.COLUMN_ITEM + " TEXT," +
                    DataBaseContract.DataEntry.COLUMN_JUMLAH + " TEXT," +
                    DataBaseContract.DataEntry.COLUMN_TOTAL + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + DataBaseContract.DataEntry.TABLE_NAME;

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

