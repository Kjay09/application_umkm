package com.example.scarpaapk;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class InformasiFragment extends Fragment {
    TextView mdesc, mharga, mnama;
    ImageView mfoto;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_detail, container, false);
        mfoto = rootView.findViewById(R.id.foto);
        mdesc = rootView.findViewById(R.id.desc);
        mharga = rootView.findViewById(R.id.harga);
        mnama = rootView.findViewById(R.id.namaproduk);

        String desc = getArguments().getString("desc");
        String harga = getArguments().getString("harga");
        String namaproduk = getArguments().getString("namaproduk");

        mdesc.setText(desc);
        mharga.setText(harga);
        mnama.setText(namaproduk);
        mfoto.setImageResource(getArguments().getInt("foto"));
        return rootView;
    }
}

