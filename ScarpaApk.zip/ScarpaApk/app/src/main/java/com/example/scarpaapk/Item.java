package com.example.scarpaapk;

public class Item {
    private String desc,harga,namaproduk;
    private int foto;

    public Item(String namaproduk, String desc, String harga, int foto){
        this.namaproduk=namaproduk;
        this.desc = desc;
        this.harga = harga;
        this.foto=foto;
    }
    public String getDesc(){return desc;}
    public String getHarga(){return harga;}
    public String getNamaproduk(){return namaproduk;}
    public int getFoto(){return foto;}
}
