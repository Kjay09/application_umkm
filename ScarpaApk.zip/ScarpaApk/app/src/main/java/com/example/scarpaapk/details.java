package com.example.scarpaapk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

public class details extends AppCompatActivity {
    GridView gridView;
    ArrayList<Item> infolist;
    Button btn_back1;

    @Override
    public void onCreate(Bundle savedInstanceStated) {
        super.onCreate(savedInstanceStated);
        setContentView(R.layout.destination);
        gridView = findViewById(R.id.gv_details);
        infolist = new ArrayList<>();
        infolist.add(new Item("Patrobas Equip Low Black White","EQUIP merupakan kombinasi dari ciri khas kedua model sepatu Patrobas, yaitu Ivan dan Hawk. Disini, kami mengadopsi bumper belakang bermotif gerigi yang sudah menjadi ciri khas dari artikel Hawk sejak tahun 2018. Kemudian pemilihan warna logo stripe Patrobas sengaja disamakan dengan warna Canvas di upper sepatu. Tujuannya agar terlihat lebih Simple dan Elegan seperti halnya artikel Hawk.",
                "Rp 199.000",R.drawable.patrobaseticlb));
        infolist.add(new Item("Patrobas Equip Low Cream","EQUIP merupakan kombinasi dari ciri khas kedua model sepatu Patrobas, yaitu Ivan dan Hawk. Disini, kami mengadopsi bumper belakang bermotif gerigi yang sudah menjadi ciri khas dari artikel Hawk sejak tahun 2018. Kemudian pemilihan warna logo stripe Patrobas sengaja disamakan dengan warna Canvas di upper sepatu. Tujuannya agar terlihat lebih Simple dan Elegan seperti halnya artikel Hawk.",
                "Rp 199.000",R.drawable.patrobaseticlm));
        infolist.add(new Item("Ventela 70s Low Cream","Memiliki desain yang minimalis tapi tetap stylish, produk sepatu Ventela banyak digemari. Salah satu jenis sepatu yang cukup populer adalah Back To 70's Series.",
                "Rp 179.000",R.drawable.ventela70slc));
        infolist.add(new Item("Ventela Public Low Green","Tampil kekinian layaknya anak millenial dengan menggunakan sepatu canvas yang lagi menjadi trend fashion dengan SEPATU CANVAS VENTELA PUBLIC LOW",
                "Rp 199.000",R.drawable.ventelapubliclg));
        infolist.add(new Item("Ventela Republic Low Black Natural","SEPATU VENTELA REPUBLIC Low 100% Original Made in Indonesia, Canvas dan teknologi Ultralite Foam sehingga sangat empuk saat digunakan saat beraktivitas seharian bagian outsole menggunakan Rubber, Cocok digunakan untuk segala aktivitas.",
                "Rp 299.000",R.drawable.ventelarepuplicb));
        infolist.add(new Item("Ventela Republic Low Cream","SEPATU VENTELA REPUBLIC Low 100% Original Made in Indonesia, Canvas dan teknologi Ultralite Foam sehingga sangat empuk saat digunakan saat beraktivitas seharian bagian outsole menggunakan Rubber, Cocok digunakan untuk segala aktivitas.",
                "Rp 299.000",R.drawable.ventelarepubliccream));
        gridView.setAdapter(new ItemAdapter(this,infolist));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                Fragment informasiFragment = new InformasiFragment();
                Bundle args = new Bundle();
                args.putString("namaproduk", infolist.get(i).getNamaproduk());
                args.putString("desc", infolist.get(i).getDesc());
                args.putString("harga", infolist.get(i).getHarga());
                args.putInt("foto", infolist.get(i).getFoto());
                informasiFragment.setArguments(args);

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, informasiFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        btn_back1 = findViewById(R.id.btn_back1);
        btn_back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(details.this, Homepage.class);
                startActivity(back);
            }
        });
    }
}
